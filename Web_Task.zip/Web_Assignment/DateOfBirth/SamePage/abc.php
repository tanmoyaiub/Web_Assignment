<?php
	
	$dob	=$_REQUEST['dob'];
	$submit	=$_REQUEST['submit'];
	
	if(isset($_REQUEST['submit'])){
		echo $dob;		
	}

?>

<!DOCTYPE html>
<html>
	<head>
		<title>DateOfBirth</title>
	</head>
	<body>
		<form method ="POST" action="abc.php">
		<fieldset width="700">
		    <legend>DateOfBirth</legend>
			<table border="0" width="700" height="80">
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
						<input type="date" name="dob" />
						<hr></hr>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
</html>