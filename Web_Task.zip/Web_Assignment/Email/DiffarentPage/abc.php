<?php
	
	$uname	=$_REQUEST['uname'];
	$submit	=$_REQUEST['submit'];
	
	if(isset($_REQUEST['submit'])){
		echo $uname;		
	}

?>