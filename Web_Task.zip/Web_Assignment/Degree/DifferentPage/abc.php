<?php
	
	$degree	=$_REQUEST['Degree'];
	echo $degree;

?>