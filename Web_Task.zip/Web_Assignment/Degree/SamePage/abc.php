<?php
	
	$degree	=$_REQUEST['Degree'];
	echo $degree;

?>

<html>
	<head>
		<title>Degree</title>
	</head>
	<body>
		<form method ="POST" action="abc.php">
		<fieldset width="700">
		    <legend>Degree</legend>
			<table border="0" width="700" height="80">
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
							<input type="checkbox" name="Degree" value="ssc"/>SSC
						<input type="checkbox" name="Degree" value="hsc"/>HSC
						<input type="checkbox" name="Degree" value="bsc"/>BSC
						<input type="checkbox" name="Degree" value="msc"/>MSC
						<hr></hr>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
</html>