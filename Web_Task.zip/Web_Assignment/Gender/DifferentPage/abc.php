<?php
	
	$gender	=$_REQUEST['Gender'];
	echo $gender;

?>