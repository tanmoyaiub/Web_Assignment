<?php
	
	$bloodgroup	=$_REQUEST['BloodGroup'];
	echo $bloodgroup;

?>

<html>
	<head>
		<title>BloodGroup</title>
	</head>
	<body>
		<form method ="POST" action="abc.php">
		<fieldset width="700">
		    <legend>BloodGroup</legend>
			<table border="0" width="700" height="80">
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
						<select name="bloodgroup">
							<option></option>
							<option value="ab+">AB+</option>
							<option value="ab-">AB-</option>
							<option value="a+">A+</option>
							<option value="a-">A-</option>
							<option value="b+">B+</option>
							<option value="b-">B-</option>
							<option value="o+">O+</option>
							<option value="o-">O-</option>
						</select>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
</html>