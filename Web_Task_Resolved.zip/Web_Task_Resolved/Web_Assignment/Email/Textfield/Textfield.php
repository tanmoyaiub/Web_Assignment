<?php
	

	$Name="";
	
	if(isset($_REQUEST['submit'])){
		$Name	=$_REQUEST['uname'];
		echo $Name;		
	}

?>

<html>
	<head>
		<title>Email</title>
	</head>
	<body>
		<form method ="POST" action="abc.php">
		<fieldset style="width: 250">
		    <legend>Email</legend>
			<table>
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
						<input type="text" name="uname" size="50" value = " <?=$Name ?>"><br/>
						<hr></hr>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
</html>