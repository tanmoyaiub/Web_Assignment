<?php
	
	$dob	=$_REQUEST['dob'];
	$submit	=$_REQUEST['submit'];
	
	if(isset($_REQUEST['submit'])){
		echo $dob;		
	}

?>