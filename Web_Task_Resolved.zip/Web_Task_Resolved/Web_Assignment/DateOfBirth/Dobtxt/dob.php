<?php
	
	
	$dob="";
	if(isset($_REQUEST['submit'])){
		
		$dob	=$_REQUEST['dob'];
		echo $dob;		
	}
	

?>

<!DOCTYPE html>
<html>
	<head>
		<title>DateOfBirth</title>
	</head>
	<body>
		<form method ="POST">
		<fieldset style="width:250">
		    <legend>DateOfBirth</legend>
			<table>
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
						<input type="text" name="day" value="<?php $dob?>"  />
						<input type="text" name="month" value="<?php $dob ?>"  />
						<input type="text" name="year" value="<?php $dob?>"/>
						<hr></hr>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
</html>