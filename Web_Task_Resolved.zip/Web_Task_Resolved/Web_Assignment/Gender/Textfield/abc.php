<?php
	
	$gender="";
	
	if(isset($_REQUEST['submit']))
	{
		$gender	=$_REQUEST['Gender'];
		echo $gender;
	}

?>


<html>
	<head>
		<title>Gender</title>
	</head>
	<body>
		<form method ="POST">
		<fieldset style="width:250">
		    <legend>Gender</legend>
			<table border="0" width="300" height="80">
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
						<input type="radio" name="Gender" value="male" <?php if($gender=='male') echo "checked"; ?>/>Male
						<input type="radio" name="Gender" value="female" <?php if($gender=='female') echo "checked"; ?>/>FeMale
						<input type="radio" name="Gender" value="other" <?php if($gender=='other') echo "checked"; ?>/>Other
						<hr></hr>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
