<?php
	
	
	
	if(isset($_REQUEST['submit']))
	{
		$gender	=$_REQUEST['Gender'];
		echo $gender;
	}

?>


<html>
	<head>
		<title>Gender</title>
	</head>
	<body>
		<form method ="POST">
		<fieldset style="width:250">
		    <legend>Gender</legend>
			<table border="0" width="300" height="80">
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
						<input type="radio" name="Gender" value="male"/>Male
						<input type="radio" name="Gender" value="female"/>FeMale
						<input type="radio" name="Gender" value="other"/>Other
						<hr></hr>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
