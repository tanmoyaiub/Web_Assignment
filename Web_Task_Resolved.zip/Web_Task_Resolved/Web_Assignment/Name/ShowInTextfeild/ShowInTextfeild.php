<?php
	
    $Name="";
	if(isset($_REQUEST['submit'])){
		$Name = $_REQUEST['uname'];
		echo $Name;		
	}
?>

<html>
	<head>
		<title>Name</title>
	</head>
	<body>
		<form method ="POST" action="">
		<fieldset style="width: 300">
		    <legend>Name</legend>
			<table>
				<tr height="50" rowspan="2">
					<td>
						<input type="text" name="uname" value = "<?= $Name ?>">
						<br>
						<hr></hr>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
</html>