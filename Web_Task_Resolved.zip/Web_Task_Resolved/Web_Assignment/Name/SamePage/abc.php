<?php
	
	$uname	="";
	$submit	="";
	
	
	if(isset($_REQUEST['submit'])){
		echo $uname;		
	}

?>

<html>
	<head>
		<title>Name</title>
	</head>
	<body>
		<form method ="POST" action="">
		<fieldset width="700">
		    <legend><b>Name</b></legend>
			<table border="0" width="700" height="80">
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
						<input type="text" name="uname" size="50"/><br/>
						<hr></hr>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
</html>