<?php
	
	$bloodgroup="";
	
	if(isset($_REQUEST['submit'])){
		
		$bloodgroup	=$_REQUEST['bloodgroup'];
		echo $bloodgroup;
	}	

?>

<html>
	<head>
		<title>BloodGroup</title>
	</head>
	<body>
		<form method ="POST" action="abc.php">
		<fieldset width="700">
		    <legend>BloodGroup</legend>
			<table border="0" width="700" height="80">
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
						<select name="bloodgroup">
							<option></option>
							<option value="AB+">AB+</option>
							<option value="AB-">AB-</option>
							<option value="A+">A+</option>
							<option value="A-">A-</option>
							<option value="B+">B+</option>
							<option value="B-">B-</option>
							<option value="O+">O+</option>
							<option value="O-">O-</option>
						</select>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
</html>