<?php
	
	$bloodgroup	=$_REQUEST['BloodGroup'];
	echo $bloodgroup;

?>