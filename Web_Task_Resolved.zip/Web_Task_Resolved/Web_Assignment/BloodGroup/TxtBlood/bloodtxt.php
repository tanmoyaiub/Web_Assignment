<?php
	
	$bloodgroup="";
	
	if(isset($_REQUEST['submit'])){
		
		$bloodgroup	=$_REQUEST['bloodgroup'];
		echo $bloodgroup;
	}	

?>

<html>
	<head>
		<title>BloodGroup</title>
	</head>
	<body>
		<form method ="POST">
		<fieldset width="700">
		    <legend>BloodGroup</legend>
			<table border="0" width="700" height="80">
				<tr height="50" rowspan="2">
					<td width="20" colspan="2">
						<select name="bloodgroup">
							<option></option>
							<option value="AB+" <?=$bloodgroup?>>AB+</option>
							<option value="AB-" <?=$bloodgroup?>>AB-</option>
							<option value="A+" 	<?=$bloodgroup?>>A+</option>
							<option value="A-" 	<?=$bloodgroup?>>A-</option>
							<option value="B+" 	<?=$bloodgroup?>>B+</option>
							<option value="B-" 	<?=$bloodgroup?>>B-</option>
							<option value="O+" 	<?=$bloodgroup?>>O+</option>
							<option value="O-" 	<?=$bloodgroup?>>O-</option>
						</select>
						<input type="submit" name="submit" value="submit"/>
					</td>
				</tr>
			</table>
		</fieldset>
		</form>
	</body>
</html>